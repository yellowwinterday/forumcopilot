<?php

/** @noinspection PhpIllegalPsrClassPathInspection */
// ################## THIS IS A GENERATED FILE ##################
// DO NOT EDIT DIRECTLY. EDIT THE CLASS EXTENSIONS IN THE CONTROL PANEL.

namespace ForumCopilot\XF\Attachment
{
	class XFCP_Manipulator extends \XF\Attachment\Manipulator {}
	class XFCP_Post extends \XF\Attachment\Post {}
}

namespace ForumCopilot\XF\Pub\Controller
{
	class XFCP_Forum extends \XF\Pub\Controller\Forum {}
	class XFCP_Thread extends \XF\Pub\Controller\Thread {}
}